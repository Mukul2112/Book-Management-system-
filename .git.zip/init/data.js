
const samplelisting=[


    {
      name: "To Kill a Mockingbird",
      imagelink: "https://m.media-amazon.com/images/I/81gepf1eMqL._AC_UF1000,1000_QL80_.jpg",
      author: "Harper Lee",
      price: 10.99,
      description: "A novel about the serious issues of rape and racial inequality, narrated by young Scout Finch.",
      reviews: [
        {
          user: "Alice",
          comment: "A timeless classic. Must-read for everyone.",
          rating: 5
        },
        {
          user: "Bob",
          comment: "The storytelling is captivating, and the characters are unforgettable.",
          rating: 4.5
        }
      ]
    },
    {
      name: "1984",
      imagelink: "https://m.media-amazon.com/images/I/612ADI+BVlL._AC_UF1000,1000_QL80_.jpg",
      author: "George Orwell",
      price: 8.99,
      description: "A dystopian novel set in a totalitarian society under constant surveillance.",
      reviews: [
        {
          user: "Charlie",
          comment: "A thought-provoking book that still feels relevant.",
          rating: 5
        },
        {
          user: "Dana",
          comment: "A chilling view of the future. Orwell was ahead of his time.",
          rating: 4
        }
      ]
    },
    {
      name: "Pride and Prejudice",
      imagelink: "https://m.media-amazon.com/images/I/712P0p5cXIL._AC_UF1000,1000_QL80_.jpg",
      author: "Jane Austen",
      price: 12.50,
      description: "A romantic novel that explores manners, marriage, and social standing in 19th-century England.",
      reviews: [
        {
          user: "Eve",
          comment: "Beautifully written, witty, and delightful.",
          rating: 4.8
        },
        {
          user: "Frank",
          comment: "An engaging love story with complex characters.",
          rating: 4.7
        }
      ]
    },
    {
      name: "The Great Gatsby",
      imagelink: "https://m.media-amazon.com/images/I/81Q6WkLhX4L._UF1000,1000_QL80_.jpg",
      author: "F. Scott Fitzgerald",
      price: 9.99,
      description: "A novel about the American Dream, wealth, and love set in the Roaring Twenties.",
      reviews: [
        {
          user: "Grace",
          comment: "A beautifully written tale of ambition and disillusionment.",
          rating: 4.9
        },
        {
          user: "Henry",
          comment: "A story that captures the essence of a lost generation.",
          rating: 4.6
        }
      ]
    },
    {
      name: "Moby-Dick",
      imagelink: "https://m.media-amazon.com/images/I/712mdW4zCcL._AC_UF1000,1000_QL80_.jpg",
      author: "Herman Melville",
      price: 11.75,
      description: "The epic tale of Captain Ahab's obsessive quest to hunt down the white whale, Moby Dick.",
      reviews: [
        {
          user: "Isaac",
          comment: "A challenging read but rewarding. The symbolism is incredible.",
          rating: 4.3
        },
        {
          user: "Julia",
          comment: "A deep dive into human nature and obsession.",
          rating: 4.0
        }
      ]
    },
      {
        name: "The Hobbit",
        imagelink: "https://m.media-amazon.com/images/I/71jKeGU9nKL._AC_UF1000,1000_QL80_.jpg",
        author: "J.R.R. Tolkien",
        price: 11.50,
        description: "A fantasy novel following Bilbo Baggins's adventurous quest with dwarves to reclaim their homeland.",
        reviews: [
          { user: "Chris", comment: "An enchanting tale full of wonder and adventure.", rating: 5 },
          { user: "Dana", comment: "Beautifully written and timeless.", rating: 4.8 }
        ]
      },
      {
        name: "The Alchemist",
        imagelink: "https://m.media-amazon.com/images/I/71fm0Ap7JcL._AC_UF1000,1000_QL80_.jpg",
        author: "Paulo Coelho",
        price: 7.99,
        description: "A philosophical novel about following one's dreams and discovering oneself.",
        reviews: [
          { user: "Erin", comment: "Inspiring and uplifting, a journey of self-discovery.", rating: 4.7 },
          { user: "Frank", comment: "Simple yet profound, it stays with you.", rating: 4.5 }
        ]
      },
     
      {
        name: "The Book Thief",
        imagelink: "https://m.media-amazon.com/images/I/91JGwQlnu7L.jpg",
        author: "Markus Zusak",
        price: 10.75,
        description: "Set in Nazi Germany, the story of a young girl who steals books and learns the power of words.",
        reviews: [
          { user: "Ivy", comment: "Emotional and impactful, beautifully written.", rating: 5 },
          { user: "Jack", comment: "Heart-wrenching story with unforgettable characters.", rating: 4.9 }
        ]
      },
      {
        name: "Life of Pi",
        imagelink: "https://m.media-amazon.com/images/I/816NlEQFMOL._AC_UF1000,1000_QL80_.jpg",
        author: "Yann Martel",
        price: 8.50,
        description: "The story of a young boy stranded on a lifeboat with a Bengal tiger.",
        reviews: [
          { user: "Karen", comment: "An amazing story of survival and faith.", rating: 4.8 },
          { user: "Leo", comment: "Unique storytelling with philosophical undertones.", rating: 4.6 }
        ]
      },
      {
        name: "The Catch-22",
        imagelink: "https://m.media-amazon.com/images/I/71Ym0vDDWsL._AC_UF1000,1000_QL80_.jpg",
        author: "Joseph Heller",
        price: 12.00,
        description: "A satirical novel about the absurdity of war and bureaucracy.",
        reviews: [
          { user: "Mona", comment: "Witty, dark, and incredibly insightful.", rating: 4.5 },
          { user: "Neil", comment: "A masterpiece of satire and dark humor.", rating: 4.7 }
        ]
      },
      {
        name: "Jane Eyre",
        imagelink: "https://m.media-amazon.com/images/I/51Xtvezf6ML._AC_UF1000,1000_QL80_.jpg",
        author: "Charlotte Brontë",
        price: 10.00,
        description: "A coming-of-age novel about a young woman's struggle for independence and love.",
        reviews: [
          { user: "Olivia", comment: "A beautiful blend of romance, mystery, and social critique.", rating: 4.8 },
          { user: "Paul", comment: "A timeless love story with a strong, complex heroine.", rating: 4.7 }
        ]
      },
      {
        name: "Crime and Punishment",
        imagelink: "https://rukminim2.flixcart.com/image/850/1000/kjd6nww0-0/book/8/p/o/crime-and-punishment-original-imafyxr46przpsps.jpeg?q=20&crop=false",
        author: "Fyodor Dostoevsky",
        price: 13.50,
        description: "A psychological drama about guilt, redemption, and morality in 19th-century Russia.",
        reviews: [
          { user: "Quinn", comment: "Intense, complex, and thought-provoking.", rating: 4.9 },
          { user: "Rose", comment: "Dostoevsky at his finest, delving deep into the human psyche.", rating: 4.8 }
        ]
      },
      {
        name: "The Road",
        imagelink: "https://m.media-amazon.com/images/I/51M7XGLQTBL._AC_UF1000,1000_QL80_.jpg",
        author: "Cormac McCarthy",
        price: 9.99,
        description: "A haunting post-apocalyptic novel about a father and son's struggle to survive.",
        reviews: [
          { user: "Sam", comment: "Haunting, poetic, and unforgettable.", rating: 4.7 },
          { user: "Tina", comment: "Bleak but beautifully written.", rating: 4.6 }
        ]
      },
      {
        name: "The Kite Runner",
        imagelink: "https://m.media-amazon.com/images/I/81IzbD2IiIL._AC_UF1000,1000_QL80_.jpg",
        author: "Khaled Hosseini",
        price: 8.75,
        description: "A story of friendship, betrayal, and redemption set in Afghanistan.",
        reviews: [
          { user: "Uma", comment: "Heartbreaking and unforgettable.", rating: 4.9 },
          { user: "Victor", comment: "A powerful tale of friendship and forgiveness.", rating: 4.8 }
        ]
      },
    
  
    {
        name: "A Tale of Two Cities",
        imagelink: "https://m.media-amazon.com/images/I/71CQFGiPA+L._AC_UF1000,1000_QL80_.jpg",
        author: "Charles Dickens",
        price: 9.99,
        description: "A historical novel set in London and Paris before and during the French Revolution.",
        reviews: [
          { user: "Wendy", comment: "Powerful and evocative; a classic.", rating: 4.7 },
          { user: "Xander", comment: "Dickens brings the turmoil of the revolution to life.", rating: 4.6 }
        ]
      },
      {
        name: "Fahrenheit 451",
        imagelink: "https://m.media-amazon.com/images/I/61l8LHt4MeL._AC_UF1000,1000_QL80_.jpg",
        author: "Ray Bradbury",
        price: 8.50,
        description: "A dystopian novel about a future where books are banned and 'firemen' burn them.",
        reviews: [
          { user: "Yara", comment: "A chilling reminder of the importance of knowledge.", rating: 4.8 },
          { user: "Zack", comment: "Haunting and thought-provoking.", rating: 4.5 }
        ]
      },
      {
        name: "The Shining",
        imagelink: "https://m.media-amazon.com/images/I/91U7HNa2NQL._AC_UF1000,1000_QL80_.jpg",
        author: "Stephen King",
        price: 10.99,
        description: "A horror novel about a family in a haunted hotel during winter.",
        reviews: [
          { user: "Alex", comment: "Terrifying and masterfully written.", rating: 4.9 },
          { user: "Bailey", comment: "King at his best with suspense and horror.", rating: 4.7 }
        ]
      },
      {
        name: "The Handmaid's Tale",
        imagelink: "https://m.media-amazon.com/images/I/61SpcaD4poL._AC_UF1000,1000_QL80_.jpg",
        author: "Margaret Atwood",
        price: 11.00,
        description: "A dystopian novel about a totalitarian society that treats women as property.",
        reviews: [
          { user: "Casey", comment: "Disturbing and powerful; a must-read.", rating: 4.8 },
          { user: "Drew", comment: "Thought-provoking and intense.", rating: 4.6 }
        ]
      },
      {
        name: "Beloved",
        imagelink: "https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1722944318i/6149.jpg",
        author: "Toni Morrison",
        price: 12.75,
        description: "A haunting novel about slavery, loss, and the past's power.",
        reviews: [
          { user: "Ella", comment: "Beautifully written and deeply moving.", rating: 4.8 },
          { user: "Finn", comment: "Morrison's writing is poetic and impactful.", rating: 4.7 }
        ]
      },
      {
        name: "The Adventures of Huckleberry Finn",
        imagelink: "https://m.media-amazon.com/images/I/91H34WEefnL._UF1000,1000_QL80_.jpg",
        author: "Mark Twain",
        price: 7.99,
        description: "A novel about a young boy's adventures along the Mississippi River.",
        reviews: [
          { user: "Grace", comment: "Witty and adventurous, a true classic.", rating: 4.5 },
          { user: "Hugo", comment: "Twain captures the spirit of America.", rating: 4.4 }
        ]
      },
      {
        name: "Anna Karenina",
        imagelink: "https://m.media-amazon.com/images/I/71O3PTUA3vL._AC_UF1000,1000_QL80_.jpg",
        author: "Leo Tolstoy",
        price: 14.50,
        description: "A tragic love story set in Russian high society.",
        reviews: [
          { user: "Isla", comment: "Heartbreaking and beautifully written.", rating: 4.7 },
          { user: "Jack", comment: "Tolstoy's characters are vivid and complex.", rating: 4.6 }
        ]
      },
      {
        name: "Dracula",
        imagelink: "https://m.media-amazon.com/images/I/91wOUFZCE+L._UF1000,1000_QL80_.jpg",
        author: "Bram Stoker",
        price: 10.25,
        description: "A Gothic horror novel about the infamous vampire Count Dracula.",
        reviews: [
          { user: "Kara", comment: "Chilling and atmospheric; a true classic.", rating: 4.8 },
          { user: "Liam", comment: "Captures the essence of horror and suspense.", rating: 4.7 }
        ]
      },
      {
        name: "Siddhartha",
        imagelink: "https://m.media-amazon.com/images/I/61urry+xagL._AC_UF1000,1000_QL80_.jpg",
        author: "Hermann Hesse",
        price: 8.25,
        description: "A philosophical novel about a man's spiritual journey to enlightenment.",
        reviews: [
          { user: "Mila", comment: "Profound and inspiring.", rating: 4.6 },
          { user: "Noah", comment: "A beautiful tale of self-discovery.", rating: 4.5 }
        ]
      },
      {
        name: "The Metamorphosis",
        imagelink: "https://m.media-amazon.com/images/I/71qR+kG+43L._AC_UF1000,1000_QL80_.jpg",
        author: "Franz Kafka",
        price: 6.99,
        description: "A surreal novella about a man who transforms into a giant insect.",
        reviews: [
          { user: "Olive", comment: "Strange, haunting, and thought-provoking.", rating: 4.5 },
          { user: "Peter", comment: "Kafka's masterpiece of existential dread.", rating: 4.4 }
        ]
      },
    
  {
    name: "The Little Prince",
    imagelink: "https://m.media-amazon.com/images/I/71t+4m5lz0L._AC_UF1000,1000_QL80_.jpg",
    author: "Antoine de Saint-Exupéry",
    price: 7.50,
    description: "A poetic tale of a young prince exploring the universe and learning about love and responsibility.",
    reviews: [
      { user: "Quinn", comment: "Magical and profound, a story for all ages.", rating: 5 },
      { user: "Riley", comment: "Simple yet deeply moving.", rating: 4.8 }
    ]
  },
  {
    name: "Don Quixote",
    imagelink: "https://m.media-amazon.com/images/I/71mbJoazlCL._AC_UF1000,1000_QL80_.jpg",
    author: "Miguel de Cervantes",
    price: 13.99,
    description: "A satirical tale of an idealistic man who believes he is a knight on a quest.",
    reviews: [
      { user: "Sophie", comment: "Witty and timeless; a story of dreams and reality.", rating: 4.6 },
      { user: "Tom", comment: "A humorous exploration of idealism and adventure.", rating: 4.7 }
    ]
  },
  {
    name: "Invisible Man",
    imagelink: "https://upload.wikimedia.org/wikipedia/commons/e/ee/Invisible_Man_%281952_1st_ed_jacket_cover%29.jpg",
    author: "Ralph Ellison",
    price: 10.50,
    description: "A novel about racial injustice and the search for identity in mid-20th-century America.",
    reviews: [
      { user: "Uma", comment: "Powerful and insightful.", rating: 4.8 },
      { user: "Victor", comment: "Ellison's narrative is gripping and profound.", rating: 4.7 }
    ]
  },
  {
    name: "Rebecca",
    imagelink: "https://rukminim2.flixcart.com/image/850/1000/k1l1ea80/book/3/8/0/rebecca-original-imaeymmzhvakszhw.jpeg?q=20&crop=false",
    author: "Daphne du Maurier",
    price: 9.75,
    description: "A gothic novel of mystery and suspense set in the haunting Manderley estate.",
    reviews: [
      { user: "Will", comment: "Dark and beautifully crafted.", rating: 4.8 },
      { user: "Xena", comment: "Haunting and mysterious; a masterpiece.", rating: 4.7 }
    ]
  },
  {
    name: "The Stranger",
    imagelink: "https://m.media-amazon.com/images/I/617WkdpG8xL._AC_UF1000,1000_QL80_.jpg",
    author: "Albert Camus",
    price: 7.99,
    description: "A novel exploring existential themes through the story of an indifferent young man.",
    reviews: [
      { user: "Yasmine", comment: "Simple yet deeply philosophical.", rating: 4.5 },
      { user: "Zane", comment: "A profound and unsettling story.", rating: 4.6 }
    ]
  },
  {
    name: "Things Fall Apart",
    imagelink: "https://m.media-amazon.com/images/I/91NtvTU0xEL._AC_UF350,350_QL50_.jpg",
    author: "Chinua Achebe",
    price: 8.50,
    description: "A novel about African tribal life and the impact of colonialism.",
    reviews: [
      { user: "Alice", comment: "Powerful narrative on tradition and change.", rating: 4.8 },
      { user: "Brian", comment: "Achebe captures the complexities of African culture.", rating: 4.7 }
    ]
  },
  {
    name: "Slaughterhouse-Five",
    imagelink: "https://m.media-amazon.com/images/I/51jLxTxTnyL._AC_UF1000,1000_QL80_.jpg",
    author: "Kurt Vonnegut",
    price: 9.99,
    description: "A satirical novel about a soldier's experiences in WWII and his surreal encounters with time travel.",
    reviews: [
      { user: "Cathy", comment: "Funny, heartbreaking, and surreal.", rating: 4.7 },
      { user: "Daniel", comment: "A powerful anti-war novel with wit.", rating: 4.6 }
    ]
  },
  {
    name: "Great Expectations",
    imagelink: "https://m.media-amazon.com/images/I/81elBAS5LcL._UF1000,1000_QL80_.jpg",
    author: "Charles Dickens",
    price: 10.25,
    description: "A coming-of-age story of an orphan named Pip and his journey through Victorian society.",
    reviews: [
      { user: "Ella", comment: "Dickens' characters are unforgettable.", rating: 4.7 },
      { user: "Frank", comment: "A tale of ambition, love, and redemption.", rating: 4.6 }
    ]
  },
  {
    name: "Les Misérables",
    imagelink: "https://rukminim2.flixcart.com/image/850/1000/xif0q/book/r/q/t/les-miserables-original-imagjznqjg9uhzys.jpeg?q=20&crop=false",
    author: "Victor Hugo",
    price: 15.00,
    description: "An epic novel of love, justice, and redemption in 19th-century France.",
    reviews: [
      { user: "Grace", comment: "Emotionally powerful and beautifully written.", rating: 5 },
      { user: "Henry", comment: "A masterpiece of historical fiction.", rating: 4.8 }
    ]
  },
 
]
       
  

  module.exports = samplelisting;
  